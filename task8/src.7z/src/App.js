import React, { Component } from 'react';
import GitHub from './GitHub';

class App extends Component { 
      
  render() {        
    return (
      <div>
        <GitHub />                        
      </div>
    );
  }
}

export default App;
